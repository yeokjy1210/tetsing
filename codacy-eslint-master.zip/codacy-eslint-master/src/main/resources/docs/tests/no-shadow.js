//#Patterns: no-shadow


var a = 3; 
function b() { 
	//#Warn: no-shadow
	var a = 10; 
}
