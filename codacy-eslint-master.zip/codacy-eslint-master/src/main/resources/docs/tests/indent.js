//#Patterns: indent


if (a) {

  //ok
  b=c;

  //#Info: indent
    b=c;
  //#Info: indent
function foo(d) {
    //#Info: indent
       e=f;
  }
}
