//#Patterns: generator-star-spacing

//#Info: generator-star-spacing
function*generator() { yield "44"; yield "55"; }

function *generator() { yield "44"; yield "55"; }
