//#Patterns: dot-notation

//#Warn: dot-notation
var x = foo["bar"];

var y = foo.bar;