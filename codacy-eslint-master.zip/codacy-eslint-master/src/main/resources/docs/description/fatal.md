There are errors that will prevent the code to run, usually syntax errors.
You must fix these issues so your code can function.

````
function _xpto(a, b}}}) {
  x = y+1
}
```

[Source](http://eslint.org/docs)
