//#Patterns: no-func-assign

function foo() {
} 
//#Warn: no-func-assign
foo = bar;
