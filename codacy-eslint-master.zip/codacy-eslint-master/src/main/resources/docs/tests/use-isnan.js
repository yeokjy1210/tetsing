//#Patterns: use-isnan

//#Err: use-isnan
if (foo == NaN) { 
// ... 
} 

//#Err: use-isnan
if (foo != NaN) {
// ... 
}
