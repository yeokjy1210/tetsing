//#Patterns: prefer-template

//#Info: prefer-template
var str = "Hello, " + name + "!";

//#Info: prefer-template
var str = "Time: " + (12 * 60 * 60 * 1000);

var str = "Hello World!";
var str = `Hello, ${name}!`
