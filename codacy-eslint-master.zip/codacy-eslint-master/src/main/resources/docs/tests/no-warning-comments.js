//#Patterns: no-warning-comments
//#Issue: {"severity": "Info", "line": 5, "patternId": "no-warning-comments"}


// TODO: this

// Normal comment
