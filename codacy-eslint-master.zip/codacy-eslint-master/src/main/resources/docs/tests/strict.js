//#Patterns: strict : {"unnamedParam":"function"}

//#Info: strict
"use strict";

var bar = function() {
    //#Info: strict
    "use strict";
    return;
};

var bar = function() {
    return;
};
