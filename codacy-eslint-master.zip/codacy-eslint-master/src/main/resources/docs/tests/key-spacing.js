//#Patterns: key-spacing


//#Info: key-spacing
var obj ={foo:42 };

var obj = {
//#Info: key-spacing
    a:    value,
    bcde: 42,
}

