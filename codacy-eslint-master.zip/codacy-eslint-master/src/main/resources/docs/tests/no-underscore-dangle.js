//#Patterns: no-underscore-dangle

//#Info: no-underscore-dangle
var _foo;
//#Info: no-underscore-dangle
foo._bar();
