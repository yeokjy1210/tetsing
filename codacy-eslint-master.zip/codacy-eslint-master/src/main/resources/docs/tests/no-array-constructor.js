//#Patterns: no-array-constructor

//#Info: no-array-constructor
Array(0, 1, 2);

Array(500); 
