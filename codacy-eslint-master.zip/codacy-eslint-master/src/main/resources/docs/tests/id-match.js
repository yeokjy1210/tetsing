//#Patterns: id-match : {"unnamedParam": "^[a-z]+([A-Z][a-z]+)*$", "properties": false}

//#Warn: id-match
var my_favorite_color = "#112C85";

var myFavoriteColor   = "#112C85";
