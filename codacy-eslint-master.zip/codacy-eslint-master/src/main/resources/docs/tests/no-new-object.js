//#Patterns: no-new-object

//#Info: no-new-object
var myObject = new Object();

var myOtherObject = {};
