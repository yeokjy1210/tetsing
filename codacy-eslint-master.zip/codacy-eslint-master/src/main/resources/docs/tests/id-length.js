//#Patterns: id-length

//#Info: id-length
var x = 3;

//#Info: id-length
var xx = 5;

var foo = 3;
