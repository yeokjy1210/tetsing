//#Patterns: no-extra-semi

//#Info: no-extra-semi
var x = 5;; 
function foo() { 
// code 
//#Info: no-extra-semi
}; 
