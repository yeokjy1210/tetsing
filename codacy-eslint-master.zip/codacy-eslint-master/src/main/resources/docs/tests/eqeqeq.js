//#Patterns: eqeqeq

//#Warn: eqeqeq
if (x == 42) {
} 
//#Warn: eqeqeq
if ("" == text) {
} 
//#Warn: eqeqeq
if (obj.getStuff() != undefined) {
} 


if (x === 42) {
} 
if ("" === text) {
} 
if (obj.getStuff() !== undefined) {
} 


