//#Patterns: spaced-comment {"unnamedParam": "never"}
//#Issue: {"severity": "Info", "line": 11, "patternId": "spaced-comment"}
//#Issue: {"severity": "Info", "line": 13, "patternId": "spaced-comment"}

//#Patterns: curly : {"unnamedParam": "all"}

//This is a comment without a whitespace at the beginning

/*This is a comment without a whitespace at the beginning*/

// This is a comment with a whitespace at the beginning

/* This is a comment with a whitespace at the beginning */
