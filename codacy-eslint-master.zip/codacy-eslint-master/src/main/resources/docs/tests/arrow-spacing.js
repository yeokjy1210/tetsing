//#Patterns: arrow-spacing

var a;
var b;
//#Info: arrow-spacing
a =>b; 
