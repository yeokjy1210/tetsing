//#Patterns: default-case

//#Err: default-case
switch (foo) { case 1: doSomething(); break; 
	       case 2: doSomething(); break; 
	       }
