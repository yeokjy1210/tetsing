//#Patterns: no-self-compare


var x = 10; 
//#Warn: no-self-compare
if (x === x) {

	x = 20; 
}
