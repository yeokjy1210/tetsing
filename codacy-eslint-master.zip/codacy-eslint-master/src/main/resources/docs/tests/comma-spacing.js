//#Patterns: comma-spacing

//#Info: comma-spacing
var foo = 1 , bar = 2;

var foo = 1, bar = 2;
