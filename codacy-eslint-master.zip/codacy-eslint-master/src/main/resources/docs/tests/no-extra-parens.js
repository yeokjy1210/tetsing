//#Patterns: no-extra-parens

//#Info: no-extra-parens
a = (b * c); 
//#Info: no-extra-parens
(a * b) + c;
//#Info: no-extra-parens
typeof (a); 
