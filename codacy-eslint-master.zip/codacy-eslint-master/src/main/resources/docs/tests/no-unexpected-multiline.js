//#Patterns: no-unexpected-multiline
//#Issue: {"severity": "Err", "line": 6, "patternId": "no-unexpected-multiline"}
//#Issue: {"severity": "Err", "line": 10, "patternId": "no-unexpected-multiline"}

var foo = bar
(1 || 2).baz();


var hello = 'world'
[1, 2, 3].forEach(addNumber);
