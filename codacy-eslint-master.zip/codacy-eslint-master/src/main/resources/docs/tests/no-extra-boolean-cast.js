//#Patterns: no-extra-boolean-cast

//#Warn: no-extra-boolean-cast
if (!!foo) { 
	// ... 
} 
if (foo) {
	// ... 
}
