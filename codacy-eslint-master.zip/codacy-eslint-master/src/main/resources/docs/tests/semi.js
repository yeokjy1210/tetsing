//#Patterns: semi

//#Info: semi
var name = "ESLint"        
object.method = function() {   
};

object.method = function() {
    // ...
//#Info: semi
}

var name = "ESLint";
