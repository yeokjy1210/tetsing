//#Patterns: space-infix-ops

//#Info: space-infix-ops
a+b
//#Info: space-infix-ops
a+ b
//#Info: space-infix-ops
a +b
//#Info: space-infix-ops
a?b:c
//#Info: space-infix-ops
const foo={b:1};

a + b

a       + b

a ? b : c

const bar = {b:1};
