//#Patterns: no-implicit-coercion

//#Info: no-implicit-coercion
var b = !!foo;  

//#Info: no-implicit-coercion
var b = ~foo.indexOf("."); 

var b = Boolean(foo)
