//#Patterns: eol-last
//#Issue: {"severity": "Info", "line": 6, "patternId": "eol-last"}

function doSmth() {
  var foo = 2;
}