//#Patterns: no-irregular-whitespace

//#Info: no-irregular-whitespace
var num = 3;

var otherNum = 5;	
