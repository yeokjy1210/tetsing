//#Patterns: curly : {"unnamedParam": "all"}

//#Info: curly
if (foo) foo++;

//#Info: curly
if (foo)
  foo++;

if (foo) {
  foo++;
}