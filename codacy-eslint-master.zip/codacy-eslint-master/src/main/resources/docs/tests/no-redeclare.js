//#Patterns: no-redeclare


var a = 3;
//#Warn: no-redeclare 
var a = 10;
