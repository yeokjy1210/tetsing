//#Patterns: object-curly-spacing

//#Info: object-curly-spacing
var obj = {'foo': 'bar' };   
//#Info: object-curly-spacing
var {x } = y;  

//#Info: object-curly-spacing
var obj = { 'foo': 'bar'};


