//#Patterns: no-new


//#Warn: no-new
new Thing();

var person = new Person();
