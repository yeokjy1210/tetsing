//#Patterns: operator-linebreak


var fullHeight = borderTop + 

		 innerHeight + 
		 borderBottom;
		 
var fullHeight = borderTop
		//#Info: operator-linebreak
               + innerHeight
		//#Info: operator-linebreak
               + borderBottom;

