//#Patterns: padded-blocks
//#Issue: {"severity": "Info", "line": 8, "patternId": "padded-blocks"}
//#Issue: {"severity": "Info", "line": 10, "patternId": "padded-blocks"}
//#Issue: {"severity": "Info", "line": 15, "patternId": "padded-blocks"}
//#Issue: {"severity": "Info", "line": 17, "patternId": "padded-blocks"}

if (a)
{                
    b();
}               

if (a) {

    b();
}               

if (a) {         
    b();

}

if (a) {  
       
    b();

}

