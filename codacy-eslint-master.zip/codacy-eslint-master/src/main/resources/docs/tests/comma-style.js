//#Patterns: comma-style



var foo = 1
//#Info: comma-style
  , bar = 2;
