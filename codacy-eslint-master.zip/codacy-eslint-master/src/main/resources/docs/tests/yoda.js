//#Patterns: yoda

//#Warn: yoda
if ("red" === color) { // ...
}

//#Warn: yoda
if (true == flag) {
    // ...
}
//#Warn: yoda
if (5 > count) {
    // ...
}

if (5 & value) {
    // ...
}

if (value === "red") {
    // ...
}
