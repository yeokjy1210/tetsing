//#Patterns: new-cap


//#Warn: new-cap
var friend = new person();

var friend = new Person();
