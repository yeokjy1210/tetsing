//#Patterns: no-restricted-modules

//#Warn: no-restricted-modules
var fs = require('fs');

//#Warn: no-restricted-modules
var os = require('os');

var crypto = require('crypto');
