//#Patterns: no-empty-character-class

//#Err: no-empty-character-class
var foo = /^abc[]/;

var foo = /^abc/;
