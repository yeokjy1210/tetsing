//#Patterns: no-new-require

//#Warn: no-new-require
var appHeader = new require('app-header');

var AppHeader = require('app-header');
