//#Patterns: constructor-super



class A {
    constructor() {
	//#Warn: constructor-super
        super();       
    }
}


