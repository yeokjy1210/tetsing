//#Patterns: semi-spacing

//#Info: semi-spacing
var a = "b" ; 

//#Info: semi-spacing
var c = "d";var e = "f";
