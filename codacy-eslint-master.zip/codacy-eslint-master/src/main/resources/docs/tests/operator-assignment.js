//#Patterns: operator-assignment

//#Info: operator-assignment
x = x + y; 
//#Info: operator-assignment
x = y * x;  
//#Info: operator-assignment      
x[0] = x[0] / y; 

x = y;
x += y;
x = y * z;
x = (x * y) * z;
