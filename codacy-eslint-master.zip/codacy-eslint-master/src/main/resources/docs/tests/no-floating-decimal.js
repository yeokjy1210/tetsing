//#Patterns: no-floating-decimal

//#Warn: no-floating-decimal
var num = .5; 
//#Warn: no-floating-decimal
var num = 2.; 
//#Warn: no-floating-decimal
var num = -.7;

var num = -0.7;
