//#Patterns: no-console

//#Info: no-console
console.log("Made it here."); 
//#Info: no-console
console.error("That shouldn't have happened.");

Console.log("Hello world!");
