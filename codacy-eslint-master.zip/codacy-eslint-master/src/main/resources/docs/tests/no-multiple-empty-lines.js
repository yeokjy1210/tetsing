//#Patterns: no-multiple-empty-lines
//#Issue: {"severity": "Info", "line": 4, "patternId": "no-multiple-empty-lines"}
var foo = 5;



var bar = 3;
