//#Patterns: dot-location


//#Warn: dot-location
var a = universe.
galaxy; 

