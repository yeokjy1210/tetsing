//#Patterns: no-multi-str

//#Warn: no-multi-str
var x = "Line 1 \
  Line 2";

var y = "Line 1\n" +
        "Line 2";
