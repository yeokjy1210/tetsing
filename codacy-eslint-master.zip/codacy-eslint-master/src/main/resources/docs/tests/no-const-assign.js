//#Patterns: no-const-assign



 const a = 0;
//#Err: no-const-assign
 a = 1; 
