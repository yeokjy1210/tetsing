//#Patterns: no-script-url

//#Warn: no-script-url
location.href = "javascript:void(0)";
