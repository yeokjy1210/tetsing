This rule enforces that each file may contain only a particular number
of classes and no more.

```
//Bad (with parameter 1):
class Foo {}
class Bar {}

//Good (with parameter 1):
class Foo {}
```

[Source](http://eslint.org/docs/rules/max-classes-per-file)
