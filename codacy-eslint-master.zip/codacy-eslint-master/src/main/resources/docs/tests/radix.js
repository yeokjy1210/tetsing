//#Patterns: radix


//#Warn: radix
var num = parseInt("071");

var num = parseInt("071", 10);
