//#Patterns: computed-property-spacing

//#Warn: computed-property-spacing
obj[foo ] 
//#Warn: computed-property-spacing
obj[ 'foo'] 


obj[foo]
obj['foo']
