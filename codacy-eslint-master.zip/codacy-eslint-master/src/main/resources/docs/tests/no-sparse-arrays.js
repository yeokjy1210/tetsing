//#Patterns: no-sparse-arrays

//#Warn: no-sparse-arrays
var items = [,,];

//#Warn: no-sparse-arrays
var colors = [ "red",, "blue" ];

var items = new Array(23);
