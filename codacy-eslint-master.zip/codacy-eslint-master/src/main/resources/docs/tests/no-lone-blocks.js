//#Patterns: no-lone-blocks

//#Info: no-lone-blocks
{ var foo = bar(); }
