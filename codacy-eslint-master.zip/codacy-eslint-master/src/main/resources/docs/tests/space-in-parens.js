//#Patterns: space-in-parens


//#Info: space-in-parens
foo( 'bar');
//#Info: space-in-parens
foo('bar' );
//#Info: space-in-parens
var foo = (1 + 2 ) * 3; 

foo();

foo('bar');

var foo = (1+2) * 3;
