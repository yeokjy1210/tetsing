//#Patterns: func-style


//#Info: func-style
function foo() {
   
}


var foo = function() {
}
