//#Patterns: no-spaced-func

//#Info: no-spaced-func
fn ()

//#Info: no-spaced-func
fn
()

fn()
