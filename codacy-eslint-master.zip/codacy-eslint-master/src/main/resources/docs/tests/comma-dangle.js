//#Patterns: comma-dangle

//#Warn: comma-dangle
var foo = { bar: "baz", qux: "quux", };

var foo = { bar: "baz", qux: "quux" };


