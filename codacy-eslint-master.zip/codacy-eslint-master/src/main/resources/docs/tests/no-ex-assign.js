//#Patterns: no-ex-assign


try { // code 
} 
catch (e) { 
//#Warn: no-ex-assign
e = 10; 
}
