//#Patterns: space-before-function-paren

//#Info: space-before-function-paren
function foo() {          
    // ...
}
//#Info: space-before-function-paren
var bar = function() {
    // ...
};

var bar = function () {
    // ...
};
