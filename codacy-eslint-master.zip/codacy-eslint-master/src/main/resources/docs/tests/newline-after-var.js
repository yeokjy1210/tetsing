//#Patterns: newline-after-var

//#Info: newline-after-var
var foo; 
foo = 5;

