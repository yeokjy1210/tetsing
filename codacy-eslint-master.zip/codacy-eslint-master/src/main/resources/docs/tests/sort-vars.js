//#Patterns: sort-vars


//#Info: sort-vars
var b, a;
//#Info: sort-vars
var a, B, c;
//#Info: sort-vars
var a, A;

var A, a;

var B, a, c;
