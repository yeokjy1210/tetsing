//#Patterns: wrap-iife

//#Info: wrap-iife
var x = function () { return { y: 1 };}();


var x = (function () { return { y: 1 };}());
