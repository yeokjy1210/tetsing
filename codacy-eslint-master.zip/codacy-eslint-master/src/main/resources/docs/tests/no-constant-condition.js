//#Patterns: no-constant-condition

//#Warn: no-constant-condition
if (false) { 
doSomethingUnfinished(); 
}
