//#Patterns: no-debugger

//#Info: no-debugger
debugger;
