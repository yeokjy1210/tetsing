//#Patterns: no-div-regex


function bar() { 
//#Warn: no-div-regex
return /=foo/; 
}
