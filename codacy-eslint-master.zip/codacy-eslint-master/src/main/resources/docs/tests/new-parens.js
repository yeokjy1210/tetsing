//#Patterns: new-parens

//#Info: new-parens
var person = new Person;


var person = new Person();
