//#Patterns: quotes : {"unnamedParam":"double"}

function main() {
  //#Info: quotes
  return 'Hello, World!';
}

//#Info: quotes
var foo = 'hello world!'


var foo = "hello world!"
