//#Patterns: camelcase

//#Info: camelcase
var my_favorite_color = "#112C85";

//#Info: camelcase
function do_something() {  
}

//#Info: camelcase
obj.do_something = function() {  
};


var myFavoriteColor   = "#112C85";




