//#Patterns: no-shadow-restricted-names

//#Warn: no-shadow-restricted-names
var undefined = "foo";

//#Warn: no-shadow-restricted-names
function NaN(){}

var Object;
