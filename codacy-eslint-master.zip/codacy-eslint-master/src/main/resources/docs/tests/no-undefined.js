//#Patterns: no-undefined


function doSomething(data) {
	//#Warn: no-undefined 
	var undefined = "hi"; 
 }
