//#Patterns: no-undef-init

//#Warn: no-undef-init
var foo = undefined; 

console.log(foo === undefined); // true
