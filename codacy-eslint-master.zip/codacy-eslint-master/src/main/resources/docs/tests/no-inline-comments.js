//#Patterns: no-inline-comments

//#Info: no-inline-comments
var a = 1; // declaring a to 1 
function getRandomNumber(){ 
	//#Info: no-inline-comments
	return 4; // chosen by fair dice roll.
 	// guaranteed to be random. 
}

 var b = 2; 
//Simple comment
 var c = 3; 
