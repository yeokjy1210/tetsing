//#Patterns: no-process-env

//#Warn: no-process-env
if(process.env.NODE_ENV === "development"){
}

if(config.env === "development") {
}
