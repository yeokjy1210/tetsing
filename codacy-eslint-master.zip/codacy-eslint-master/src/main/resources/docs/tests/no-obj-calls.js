//#Patterns: no-obj-calls

//#Err: no-obj-calls
var x = Math(); 
//#Err: no-obj-calls
var y = JSON();

var x = math();
var y = json();
