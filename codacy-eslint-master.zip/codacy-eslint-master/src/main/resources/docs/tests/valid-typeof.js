//#Patterns: valid-typeof

//#Err: valid-typeof
typeof foo === "strnig"  
//#Err: valid-typeof 
typeof foo == "undefimed"
//#Err: valid-typeof
typeof bar != "nunber"

typeof foo === "string"
typeof bar == "undefined"
typeof foo === baz
