//#Patterns: space-unary-ops

//#Info: space-unary-ops
typeof!foo;     
  
//#Info: space-unary-ops
void{foo:0};

//#Info: space-unary-ops
new[foo][0];

//#Info: space-unary-ops
delete(foo.bar);


delete foo.bar;

new Foo;

void 0;

++foo;
