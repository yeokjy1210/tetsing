//#Patterns: no-alert

//#Info: no-alert
alert("here!");
