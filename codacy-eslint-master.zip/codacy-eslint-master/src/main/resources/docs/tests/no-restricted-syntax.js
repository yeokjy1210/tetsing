//#Patterns: no-restricted-syntax

//#Info: no-restricted-syntax
var doSomething = function () {};

me.dontMess();
