//#Patterns: no-mixed-spaces-and-tabs

function add(x, y){
//#Info: no-mixed-spaces-and-tabs
		 	return x + y;
}

function sub(x, y){
  return x - y;
}

function main() {
//#Info: no-mixed-spaces-and-tabs
	 	 y = 7;         
}