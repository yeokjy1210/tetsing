//#Patterns: no-trailing-spaces

//#Info: no-trailing-spaces
var foo = 0;   			 	
//#Info: no-trailing-spaces
var baz = 5; 	  	 	 					 	 	 		 			 	
