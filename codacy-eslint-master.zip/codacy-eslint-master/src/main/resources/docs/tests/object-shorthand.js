//#Patterns: object-shorthand

var foo = {
	//#Info: object-shorthand
	x: function() {},  
	//#Info: object-shorthand
	y: function *() {}, 
	//#Info: object-shorthand
	z: z               
};

var foo = {
    x() {},
    *y() {},
    z
};
