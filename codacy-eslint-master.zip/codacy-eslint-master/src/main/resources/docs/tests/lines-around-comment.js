//#Patterns: lines-around-comment
//#Issue: {"severity": "Info", "line": 12, "patternId": "lines-around-comment"}

var x = 0;

/**
 * The vertical position.
 */
var y = 10;

var x = 0;
/* the vertical position */
var y = 10;
