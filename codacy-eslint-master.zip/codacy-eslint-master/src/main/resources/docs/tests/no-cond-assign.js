//#Patterns: no-cond-assign

//#Warn: no-cond-assign 
if (user.jobTitle = "manager") { 
}

if (user.jobTitle == "manager") { 

}
