//#Patterns: array-bracket-spacing


//#Info: array-bracket-spacing
var arr = [ 'foo', 'bar'];
//#Info: array-bracket-spacing
var [x, y ] = z; 

var [x, y] = z; 
