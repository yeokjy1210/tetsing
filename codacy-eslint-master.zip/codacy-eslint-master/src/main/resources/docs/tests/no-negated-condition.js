//#Patterns: no-negated-condition

//#Info: no-negated-condition
if (!a){ 
	doSomething(); 
} 
else{ 
	doSomethingElse(); 
}
