//#Patterns: no-native-reassign

//#Warn: no-native-reassign
String = "hello";
