//#Patterns: func-names

//#Info: func-names
Foo.prototype.bar = function(){
	var boo = 1;
}

Foo.prototype.bar = function bar() {
	var baz = 1;
}
