//#Patterns: block-spacing

//#Warn: block-spacing
if (foo) { bar = 0;}

function foo() { return true; }
