//#Patterns: init-declarations

//#Info: init-declarations
var foo; 
//#Info: init-declarations
var bar;

var baz = 1;
