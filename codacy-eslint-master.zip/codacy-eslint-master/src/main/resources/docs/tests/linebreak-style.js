//#Patterns: linebreak-style

//#Info: linebreak-style
var a = 'a', // \r\n
 
b = 'b'; // \n
