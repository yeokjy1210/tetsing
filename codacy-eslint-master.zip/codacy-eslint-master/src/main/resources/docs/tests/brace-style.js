//#Patterns: brace-style


if (foo)
//#Info: brace-style
{
	bar();
//#Info: brace-style
}

else { 
	baz(); 
}
