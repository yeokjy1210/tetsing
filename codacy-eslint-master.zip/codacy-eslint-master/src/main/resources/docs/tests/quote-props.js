//#Patterns: quote-props


var object = {
	//#Info: quote-props
   	foo: "bar",
	//#Info: quote-props     
        baz: 42,
        "qux-lorem": true
};

var object1 = {
    "foo": "bar",
    "baz": 42,
    "qux-lorem": true
};
