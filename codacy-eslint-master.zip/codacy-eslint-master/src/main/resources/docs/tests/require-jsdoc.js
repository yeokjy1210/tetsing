//#Patterns: require-jsdoc

//#Info: require-jsdoc
function foo() { 
	return 10; 
}
