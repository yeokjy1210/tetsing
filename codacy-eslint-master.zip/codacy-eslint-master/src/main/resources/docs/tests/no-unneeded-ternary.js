//#Patterns: no-unneeded-ternary

//#Info: no-unneeded-ternary
var isYes = answer === 1 ? true : false;

//#Info: no-unneeded-ternary
var isNo = answer === 1 ? false : true;


var isYes = answer !== 1;
