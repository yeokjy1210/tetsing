//#Patterns: no-empty

//#Info: no-empty
if (foo) { }

try {
    doSomething();
} catch (ex) {
    // Do nothing
}
