This rule enforces a maximum number of lines per function, in order to aid in maintainability and reduce complexity.

[Source](http://eslint.org/docs/rules/max-lines-per-function)
