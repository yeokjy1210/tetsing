//#Patterns: no-regex-spaces

//#Warn: no-regex-spaces
var re = /foo   bar/;

var re = /foo {3}bar/;
