//#Patterns: arrow-parens

//#Info: arrow-parens
if (a => 2) {
}


if (a >= 2) {
}
