//#Patterns: no-useless-concat

//#Info: no-useless-concat
var a = 'some' + 'string';
//#Info: no-useless-concat
var a = '1' + '0';  


var foo = "ab";
var c = '1' + a;
var a = 1 + '1';
