//#Patterns: no-eq-null

//#Warn: no-eq-null
if (foo == null) { 
	bar();
}

if (foo === null) { 
	bar();
}
