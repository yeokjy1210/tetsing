//#Patterns: no-undef

//#Warn: no-undef
var a = someFunction(); 

//#Warn: no-undef
 b = 10; 
